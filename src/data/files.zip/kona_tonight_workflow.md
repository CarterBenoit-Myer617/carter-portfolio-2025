# TONIGHT'S WORKFLOW — KONA COFFEE
## Target: 6:00pm start

---

## BEFORE YOU SIT DOWN
- [ ] Figma file open, Kona Coffee assets exported or ready to export
- [ ] Terminal open at portfolio root
- [ ] `kona_coffee_data.json` moved to `~/Documents/portfolio/data/`
- [ ] `manifest.py` updated with KONA_COFFEE_2024 block

---

## PHASE 1 — EXPORT (20 min)
Pull assets from Figma at exact dimensions:

| Slot | Folder | Export Size | Type |
|------|--------|-------------|------|
| 01 Project Overview | `01_project_overview/` | 1920×1080 | 2–4 imgs for loop **or** drop .mp4 |
| 02 Challenge | `02_challenge/` | 1080×1920 | 1 hero img **or** vertical video |
| 03 Design Constraints | `03_design_constraints/` | 1080×1350 | 1 hero img |
| 04 Key Insight | `04_key_insight/` | 1920×1080 | 2–4 imgs for loop **or** drop .mp4 |
| 05 Design Process | `05_design_process/` | 1080×1080 | 1 hero img |
| 06 Final Solution | `06_final_solution/` | 1080×1920 | 1 hero img **or** vertical video |
| 07 System Thinking | `07_system_thinking/` | 1920×1080 | 2–4 imgs for loop **or** drop .mp4 |
| 08 Results & Impact | `08_results_impact/` | 1080×1920 | 1 hero img |
| 09 Reflection | `09_reflection/` | 1080×1350 | 1 hero img |

> Any slot can be video or static — just drop the right file type into the folder.
> Ready-made .mp4 always takes priority over image sequences.

---

## PHASE 2 — PROCESS (10 min)
```bash
# Sort exports into section folders
python3 audit_cleanup.py ~/portfolio --sort --project KONA_COFFEE_2024

# Generate video loops for any image-sequence slots
python3 batch_process_v3.py --videos-only ~/portfolio --project KONA_COFFEE_2024

# Verify 9/9 ready
python3 batch_process_v3.py --status ~/portfolio
```
Look for: `🟢 KONA_COFFEE_2024 (9/9 ready)`

---

## PHASE 3 — FIGMA MAKE (30 min)
Open `kona_figma_make_prompts.md` — work top to bottom.

**Order:**
1. Video slots first → 01, 04, 07
2. Static slots → 02, 03, 05, 06, 08, 09
3. Page header text last
4. Nav links (prev/next) last

Verify each slot plays/renders before moving to the next.

---

## PHASE 4 — BROWSER CHECK (10 min)
- [ ] Videos autoplay + loop on desktop
- [ ] Hover overlays show label / heading / body
- [ ] Mobile: videos muted + playsinline
- [ ] Nav links → Anansi (prev) and Flavien (next) resolve correctly
- [ ] No placeholder Unsplash images remaining

---

## TOTAL: ~70 min
```
6:00  Export from Figma
6:20  Run scripts, generate videos
6:30  Populate Figma Make slots
7:00  Browser audit
7:10  Done ✓
```
