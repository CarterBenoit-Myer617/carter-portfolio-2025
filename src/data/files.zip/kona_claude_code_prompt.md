# CLAUDE CODE PROMPT — KONA COFFEE CMS DATA POPULATION
## Carter Benoit-Myer Portfolio System

---

## CONTEXT

I have a portfolio system built in Figma Make (live at carterbenoitmyer.com) with a 9-slot case study template.

The CMS is an Excel file: `Carter_BenoitMyer_CMS_v4_1.xlsx` with a `PROJECT_INDEX` sheet.

The 9 content columns that map to Figma Make slots are:
- `Project_Overview` → Row 1: Full-width 1339×867 (16:9 — video OR static)
- `Challenge` → Row 2L: Left 30% 402×1059 (9:16 — video OR static)
- `Design_Constraints` → Row 2R: Right 70% 937×1059 (4:5 — video OR static)
- `Key_Insight` → Row 3: Full-width 1339×867 (16:9 — video OR static)
- `Design_Process` → Row 4L: Left 60% 803×1059 (1:1 — video OR static)
- `Final_Solution` → Row 4R: Right 40% 536×1059 (9:16 — video OR static)
- `System_Thinking` → Row 5: Full-width 1339×867 (16:9 — video OR static)
- `Results_Impact` → Row 6L: Left 30% 402×1059 (9:16 — video OR static)
- `Reflection` → Row 6R: Right 70% 937×1059 (4:5 — video OR static)

Asset type per slot is determined by what's available in the project folder:
- Drop a ready-made `.mp4` → used as-is (takes priority)
- Drop 2+ images → auto-generates looping MP4
- Drop 1 image → used as static
Update `manifest.py` KONA_COFFEE_2024 block to reflect final asset decisions.

---

## TASK

The current live site shows a placeholder project called "Kona Coffee." I need you to:

1. Create a `kona_coffee_data.json` file with the structured content below mapped to all 9 slots
2. Update the Excel CMS to add a new row for `KONA_COFFEE_2024` with all content fields populated
3. Generate a `kona_figma_make_prompts.md` file with copy-paste prompts for each slot in Figma Make
4. Flag any copy that may need tightening against the Unstoppable Hire criteria (outcome-focused, no grandiosity, CD-ready)

---

## SOURCE COPY — MAPPED TO 9 SLOTS

### PROJECT METADATA
```
Project_ID: KONA_COFFEE_2024
New_Slug: kona-coffee-luxury-brand-packaging
Public_Title_Short: Kona Coffee
H1_Title: Kona Coffee — Luxury Brand & Provenance System
Year: 2024
Category: Identity
Roles: Designer, Strategist
Tools: Figma, Illustrator, Adobe CC
Disciplines: Brand Strategy, Identity Design, Packaging Architecture, Provenance System, Conservation Partnership
Abstract: Packaging system that proves authenticity in a market where 90% of "Kona" coffee is counterfeit or diluted. Shifted brand positioning from grocery commodity to collectible single-origin product.
```

### SLOT 01 — Project_Overview (Full-width hero, 16:9 video slot)
**Label:** CONTEXT  
**Heading:** The Problem  
**Body:** Genuine Kona coffee suffers from asymmetric information—it's frequently counterfeited or diluted, eroding consumer trust and suppressing prices for legitimate producers. The market treats a rare, single-origin product like a grocery commodity.

**Overlay intro (page header):**  
"Luxury isn't communicated through tropical clichés—it's communicated through proof of scarcity and origin. The design challenge: move Kona out of the coffee aisle and into the luxury tier alongside fine wine and single malt."

---

### SLOT 02 — Challenge (Left 30%, 9:16 vertical static)
**Label:** STRATEGY  
**Heading:** Strategic Insight  
**Body:** Luxury isn't communicated through tropical clichés—it's communicated through proof of scarcity and origin.

---

### SLOT 03 — Design_Constraints (Right 70%, 4:5 portrait static)
**Label:** CONCEPT  
**Heading:** Geological Fingerprint  
**Body:** Shifted the visual narrative from "flavor notes" to "geological fingerprint," using the estate's specific position on Hualalai's volcanic slopes as the brand's core asset.

---

### SLOT 04 — Key_Insight (Full-width, 16:9 video slot)
**Label:** IDENTITY  
**Heading:** The System  
**Body:** Built a K-O-N-A lettermark arranged as a compass/diamond—evoking both navigation heritage and volcanic topography. This mark becomes the brand's authentication signature.

---

### SLOT 05 — Design_Process (Left 60%, 1:1 square static)
**Label:** DESIGN DECISION  
**Heading:** Tactile Price Justification  
**Body:** Engineered an unboxing experience (rigid structure, foil stamping, texture-mapped embossing) that psychologically validates the $85/lb price point.

---

### SLOT 06 — Final_Solution (Right 40%, 9:16 vertical static)
**Label:** DESIGN DECISION  
**Heading:** Terroir Over Flavor  
**Body:** Replaced generic tasting notes with topographical data proving the coffee's 10-mile-radius provenance.

---

### SLOT 07 — System_Thinking (Full-width, 16:9 video slot)
**Label:** IMPACT  
**Heading:** Results  
**Body:** Created a provenance system that functions as anti-counterfeiting design. Shifted brand perception from commodity to collectible origin product.

---

### SLOT 08 — Results_Impact (Left 30%, 9:16 vertical static)
**Label:** DESIGN DECISION  
**Heading:** Cultural Bridge  
**Body:** Adapted traditional lauhala weaving patterns into contemporary packaging structure—honoring Hawaiian craft without appropriating it.

---

### SLOT 09 — Reflection (Right 70%, 4:5 portrait static)
**Label:** NEXT STEPS  
**Heading:** Reflection  
**Body:** Next iteration would integrate blockchain provenance tracking into the packaging QR system and develop motion content for e-commerce unboxing storytelling.

**Bonus content (Partnership — can be appended to Reflection or used as alt):**  
Established visual framework for Conservation International 'Mother Our Nature' partnership. Designed packaging architecture that scales across SKUs while maintaining luxury positioning.

---

## OUTPUT FILES NEEDED

### 1. `kona_coffee_data.json`
Structure:
```json
{
  "project_id": "KONA_COFFEE_2024",
  "slug": "kona-coffee-luxury-brand-packaging",
  "title": "Kona Coffee",
  "year": 2024,
  "category": "Identity",
  "disciplines": [...],
  "abstract": "...",
  "slots": {
    "01_project_overview": { "label": "...", "heading": "...", "body": "..." },
    "02_challenge": { ... },
    ...
    "09_reflection": { ... }
  },
  "nav": {
    "prev_project": "Anansi Snowboard",
    "prev_slug": "anansi-the-spider-afro-futurist-snowboard",
    "next_project": "Flavien Sound",
    "next_slug": "flavien-berger-concert-posters"
  }
}
```

### 2. Excel CMS update
Add row to `PROJECT_INDEX` sheet with all fields populated. Set `Copy_Status` to `"Ready"`.  
Preserve all existing rows. Save as `Carter_BenoitMyer_CMS_v4_2.xlsx`.

### 3. `kona_figma_make_prompts.md`
For each of the 9 slots, generate a copy-paste Figma Make prompt in this format:

```
## SLOT [N] — [Section Name]

**Figma Make Prompt:**
In the [Row X] [position] slot of the Kona Coffee case study page, update the overlay text:
- Label: "[LABEL]"  
- Heading: "[HEADING]"
- Body: "[BODY]"

Leave the media slot (image/video) empty for now — asset will be uploaded separately.
```

---

## COPY AUDIT — CHECK THESE AGAINST CD CRITERIA

Before finalizing, flag any line that:
- Claims impact that wasn't measured (e.g., "shifted brand perception" — was this validated?)
- Uses cultural terminology that could read as appropriation
- Overstates student/spec work as commercial outcome
- Reads as mission statement rather than design decision

Mark flagged lines with `⚠️ REVIEW` and suggest tighter alternatives.

---

## FILE LOCATIONS

- Excel CMS: `~/Documents/portfolio/Carter_BenoitMyer_CMS_v4_1.xlsx`
- Output JSON: `~/Documents/portfolio/data/kona_coffee_data.json`
- Output Excel: `~/Documents/portfolio/Carter_BenoitMyer_CMS_v4_2.xlsx`
- Output prompts: `~/Documents/portfolio/kona_figma_make_prompts.md`

Adjust paths to match your actual folder structure before running.

---

## DEPENDENCIES

```bash
pip install openpyxl
```

---

## NOTES

- Kona Coffee is a **placeholder/demo project** on the current live site, not in the existing PROJECT_INDEX. This prompt adds it as a real entry.
- The live site shows it positioned between "Anansi Snowboard" (prev) and "Flavien Sound" (next) — maintain that nav order.
- `manifest.py` asset config for this project should default to: video for slots 01, 04, 07 — static for all others.
- If Kona is actually a spec/student project, update `Tier` to `2` and `Verdict` to `✅ KEEP`.
